# Random code to hold onto
self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(X, y, test_size=0.25)